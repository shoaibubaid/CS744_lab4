1. server.c
To run server, use the format
bash loadgen.sh <no.of.clients> 127.0.0.1 8080 

2. server_select.c
To run server, use the format
bash loadgen.sh <no.of.clients> 127.0.0.1 8081 

3. server_epoll.c
To run server, use the format
bash loadgen.sh <no.of.clients> 127.0.0.1 8082 

4. kserver.c
To run server, use the format
bash loadgen.sh <no.of.clients> 127.0.0.1 8083 

5. server_select.c
To run server, use the format
bash loadgen.sh <no.of.clients> 127.0.0.1 8084

6. server_epoll.c
To run server, use the format
bash loadgen.sh <no.of.clients> 127.0.0.1 8085 

time ./loadgen.sh 10 127.0.0.1 <port>