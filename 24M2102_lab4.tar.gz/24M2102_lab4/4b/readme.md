1. Where did the money go?
Task 1A: Don’t touch my Money
./addmillion10.o 

Task 1B: The Sweet Spot
./addmillion_modified.o <no.of.threads>


2. Task server with a thread pool
./taskqueue_multithreaded.o tasklistmultithreaded <no.of.threads>


3. Multi-threaded Server
i.
./multi_threaded_server.o 8080 <no.of.threads>


ii.
./multi_threaded_server_2.o 8081 <no.of.threads>